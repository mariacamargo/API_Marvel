import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';

const users = [
  { ra: '010623083', senha: '010623083' }
];

const Login = () => {
  const [ra, setRa] = useState('');
  const [senha, setSenha] = useState('');
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();

    const user = users.find((user) => user.ra === ra && user.senha === senha);

    console.log(ra, senha);

    if (user) {
      localStorage.setItem('user', user.ra);
      navigate('/marvel');
    } else {
      alert('RA ou senha inválidos!');
    }
  };

  return (
    <div className="login-container">
      <h2>Login</h2>
      <form onSubmit={handleLogin}>
        <div>
          <label>RA:</label>
          <input
            type="text"
            value={ra}
            onChange={(e) => setRa(e.target.value)}
            required
            placeholder="Ex: 010623083"
          />
        </div>
        <div>
          <label>Senha:</label>
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            required
            placeholder="senha(010623083)"
          />
        </div>
        <button type="submit">Entrar</button>
      </form>
    </div>
  );
};

export default Login;
